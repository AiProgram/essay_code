public class RunCodeGroup {
    public void getLPGroup(String graphDataFolder)
    {

    }
}
