import utilities as util
if __name__=="__main__":
    util.collect_data_csv()