import GeneralSnapGraph as gsg
import os
if __name__=="__main__":
    gsg.run_new_alg_group(max_com_vertex=10,repeat_time=50,is_direct_graph=False)